function fetchrefresh(){
    fetch("/data",{
        method : "get"
    })
    .then(function(dbres){
        // console.log(dbres.json());
        dbres.json().then(res => {
            res.forEach(function(val, idx){
            document.getElementById("grid").innerHTML+= `
            <tr>
                <td>${idx + 1}</td>
                <td>${val.title}</td>
                <td>${val.firstname}</td>
                <td>${val.lastname}</td>
                <td>${val.city}</td>
                <td>
                    <button data-bs-toggle="collapse" data-bs-target=".hidebox" data-hid="${val._id}" class="btn btn-warning">Edit / Update</button>
                </td>
                <td>
                    <button data-hid="${val._id}" class="btn btn-danger">Delete</button>
                </td>
            </tr>
            `
        }) 
        })
 
    })
    .catch(function(err){
        console.log(err)
    })
}
document.addEventListener("DOMContentLoaded", function(){
    fetchrefresh();
})