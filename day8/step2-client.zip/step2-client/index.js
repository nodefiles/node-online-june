const express = require("express");
let app = express();
app.use(express.static(__dirname+"/public"));
let callbackfun = (err) => {
    if(err) console.log("Error ", err)
    else console.log("Client file is now served on localhost:6060")
}
app.listen(6060,"localhost",callbackfun);