const express = require("express");
const mongoose = require("mongoose");
const config = require("./config/config.json");
const routes = require("./routes/hero.routes");
const cors = require("cors");
let app = express();
// middleware configurations
app.use(cors()); 
app.use(express.json()); 
app.use(routes);

// connect to DB
let url = `mongodb+srv://${config.user}:${config.pass}@cluster0.${config.dbsecret}.mongodb.net/${config.dbname}?retryWrites=true&w=majority&appName=Cluster0`;
// let url = "mongodb://localhost:27017/offlineDB";
mongoose.connect(url)
.then(function(dbres){
    console.log("DB Connected");
}).catch(function(err){
    console.log("Error ", err)
})

app.listen(config.port, config.host, (err) => {
    if(err){ console.log("Error is ", err)}
    else{ console.log("server is now live on localhost:5050")}
})