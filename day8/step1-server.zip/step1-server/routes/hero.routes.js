const express = require("express");
const Hero = require("../models/hero.model");
const routes = express.Router();

routes.post("/data", (req, res)=>{
    console.log("new hero value was recieved", req.body);
    let hero = new Hero({
        title:req.body.title,
        firstname:req.body.firstname,
        lastname:req.body.lastname,
        city:req.body.city
    });
    hero.save()
     .then(function(dbres){
       // console.log(dbres.title," Was Added to Database")
       res.status(200).send({message : dbres.title+" was added to DB"})
     })
     .catch(function(err){
        res.status(500).send({message: "hero was not added, please try after some time"})
     }) 
} );
// READ
routes.get("/data", (req, res)=>{
    Hero.find()
    .then(function(dbres){
        res.status(200).send(dbres)
    }).catch(function(err){
        res.status(500).send({"message": "something went wrong on the server please try after some time"})
        console.log("Error" , err)
    })
} ); 
// SELECT TO UPDATE
routes.get("/edit/:eid", (req, res)=>{
    Hero.findById(req.params.eid)
    .then(function(dbres){
        res.status(200).send(dbres)
    }).catch(function(err){
        res.status(500).send({"message": "something went wrong on the server please try after some time"})
        console.log("Error" , err)
    })
} ); 
// UPDATE
routes.put("/edit/:hid", (req, res)=>{
    Hero.findByIdAndUpdate(req.params.hid,{
        title : req.body.title,
        firstname : req.body.firstname,
        lastname : req.body.lastname,
        city : req.body.city,
    })
    .then(function(dbres){
        res.status(200).send({message : "hero info was updated"})
    })
    .catch(function(err){
        console.log("Error" , err)
        res.status(500).send({"message": "hero was not updated please try after some time"})
    })
} ); 
// DELETE
routes.delete("/delete/:hid", (req, res)=>{
    Hero.findByIdAndDelete({ _id: req.params.hid })
    .then(function(dbres){
        res.status(200).send({message : dbres.title+" was deleted from DB"})
    })
    .catch(function(err){
        console.log("Error" , err);
        res.status(500).send({message: "hero was not deleted, please try after some time"})
    }) 
} );  

module.exports = routes;