const express = require("express");
const fs = require("node:fs");
let app = express();

//-- configuration for express
app.use(express.urlencoded({extended:true}));
let rawdata = [];
let url = "data/heroes.json";
app.get("/", (req, res)=>{
    // res.render("home.ejs",{ company : "Intellipaat" } )
    fs.readFile(url,"utf-8",function(err, data){
        if(err){ 
            console.log("Error", err)
        }
        else{
            rawdata = JSON.parse(data).avengers;
            res.render("home.pug", { company : "Intellipaat", avengers : JSON.parse(data).avengers } )
        }
    })
} );

app.post("/", (req, res)=>{
    let templist = { "avengers" : [...rawdata,req.body.newhero] };
    fs.writeFile(url,JSON.stringify(templist),"utf-8",function(err){
        if(err){ console.log("Error ", err)}
        else{
            res.redirect("/");
        }
    })
} );

app.listen(5050, "localhost", (err) => {
    if(err){ console.log("Error is ", err)}
    else{ console.log("server is now live on localhost:5050")}
})