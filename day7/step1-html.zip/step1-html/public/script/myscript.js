document.addEventListener("DOMContentLoaded", function(){
    document.querySelector("img").addEventListener("click", function(){
        alert("you clicked the logo")
    })
})