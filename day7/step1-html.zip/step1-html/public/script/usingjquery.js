function refresh(){
    $.ajax({
        method : "get",
        url : "/data",
        success : function(result){
            // console.log(result)
            $("#grid").empty();
            result.forEach(function(val, idx){
                $("#grid").append(`
                     <tr>
                        <td>${idx + 1}</td>
                        <td>${val.title}</td>
                        <td>${val.firstname}</td>
                        <td>${val.lastname}</td>
                        <td>${val.city}</td>
                        <td>
                            <button data-hid="${val._id}" class="btn btn-warning">Edit / Update</button>
                        </td>
                        <td>
                            <button data-hid="${val._id}" class="btn btn-danger">Delete</button>
                        </td>
                    </tr>
                `)
            })
        },
        error : function(error){
            console.log(error)
        }

    })
}

function addHeroHandler(){
    let newhero = {
        "title" : $("#herotitle").val(),
        "firstname" : $("#herofirstname").val(),
        "lastname" : $("#herolastname").val(),
        "city" : $("#herocity").val(),
    }
    $.ajax({
    method : "post",
    url : "/data",
    contentType : "application/json",
    dataType : "json",
    data : JSON.stringify(newhero),
    success : function(result){
        refresh();
    },
    error : function(error){
        console.log(error)
    }
}) 
};

function deleteHeroHandler(evt){
    // alert(evt.target.getAttribute("data-hid"));
    $.ajax({
        method : "delete",
        url : "/delete/"+evt.target.getAttribute("data-hid"),
        success : function(result){
           refresh();
        },
        error : function(error){
            console.log(error)
        }
    })
};

function editHeroHandler(evt){
    $.ajax({
        method : "get",
        url : "/edit/"+evt.target.getAttribute("data-hid"),
        success : function(result){
           $("#editherotitle").val(result.title)
           $("#editherofirstname").val(result.firstname)
           $("#editherolastname").val(result.lastname)
           $("#editherocity").val(result.city)
           $("#editheroid").val(result._id);
           $(".edithero").show(500);
           $(".addhero").hide(500);
        },
        error : function(error){
            console.log(error)
        }
    })
};

function updateHeroHandler(){
    let newhero = {
        "title" : $("#editherotitle").val(),
        "firstname" : $("#editherofirstname").val(),
        "lastname" : $("#editherolastname").val(),
        "city" : $("#editherocity").val(),
    }
    $.ajax({
    method : "put",
    url : "/edit/"+$("#editheroid").val(),
    contentType : "application/json",
    dataType : "json",
    data : JSON.stringify(newhero),
    success : function(result){
        refresh();
        $("#editherotitle").val('');
        $("#editherofirstname").val('');
        $("#editherolastname").val('');
        $("#editherocity").val('');
        $("#editheroid").val('');
        $(".edithero").hide(500);
        $(".addhero").show(500);
    },
    error : function(error){
        console.log(error)
    }
}) 
};

$(function(){
   refresh();
   $("#addbtn").on("click", addHeroHandler);
   $("#grid").on("click", ".btn.btn-danger", deleteHeroHandler);
   $("#grid").on("click", ".btn.btn-warning", editHeroHandler);
   $("#editbtn").on("click", updateHeroHandler);
   $(".edithero").hide();
}); 