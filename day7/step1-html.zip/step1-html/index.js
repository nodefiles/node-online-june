const express = require("express");
const mongoose = require("mongoose");
const config = require("./config.json");
let app = express();
// app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use(express.static(__dirname+"/public"));

//==================================
// model to map the values in DB
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
// model
let Hero = mongoose.model("Hero",new Schema({
    id : ObjectId,
    title:String,
    firstname:String,
    lastname:String,
    city:String
}));

// connect to DB
let url = `mongodb+srv://${config.user}:${config.pass}@cluster0.${config.dbsecret}.mongodb.net/${config.dbname}?retryWrites=true&w=majority&appName=Cluster0`;
// let url = "mongodb://localhost:27017/offlineDB";
mongoose.connect(url)
.then(function(dbres){
    console.log("DB Connected");
}).catch(function(err){
    console.log("Error ", err)
})

setTimeout(function(){
    /*  READ 
    Hero.find()
    .then(function(dbres){
        console.log(dbres)
    }).catch(function(err){
        console.log("Error" , err)
    }) 
   */ 

   /* CREATE
    let hero = new Hero({
    title:"Captain America",
    firstname:"Steve",
    lastname:"Roggers",
    city:"New York"
   });
   hero.save()
   .then(function(dbres){
    console.log(dbres.title," Was Added to Database")
   })
   .catch(function(err){
    console.log("Error" , err)
   }) 
    */
    // Hero.findByIdAndDelete("6693f5d69a34b9c0685a09db")
    /*  DELETE  
    Hero.findByIdAndDelete({ _id: "6693f5d69a34b9c0685a09db" })
   .then(function(dbres){
    console.log(dbres.title," was deleted")
   })
   .catch(function(err){
    console.log("Error" , err)
   }) 
    */
   /* UPDATE
   Hero.findByIdAndUpdate("6693edb334138b06926062bb",{
     title:"Iron Monger"
   })
   .then(function(dbres){
    console.log(dbres.title," is the new title")
   })
   .catch(function(err){
    console.log("Error" , err)
   }) 
    */
},2000)

// 

//==================================

// CRUD

// CREATE
app.post("/data", (req, res)=>{
    console.log("new hero value was recieved", req.body);
    let hero = new Hero({
        title:req.body.title,
        firstname:req.body.firstname,
        lastname:req.body.lastname,
        city:req.body.city
    });
    hero.save()
     .then(function(dbres){
       // console.log(dbres.title," Was Added to Database")
       res.status(200).send({message : dbres.title+" was added to DB"})
     })
     .catch(function(err){
        res.status(500).send({message: "hero was not added, please try after some time"})
     }) 
} );
// READ
app.get("/data", (req, res)=>{
    Hero.find()
    .then(function(dbres){
        res.status(200).send(dbres)
    }).catch(function(err){
        res.status(500).send({"message": "something went wrong on the server please try after some time"})
        console.log("Error" , err)
    })
} ); 
// SELECT TO UPDATE
app.get("/edit/:eid", (req, res)=>{
    Hero.findById(req.params.eid)
    .then(function(dbres){
        res.status(200).send(dbres)
    }).catch(function(err){
        res.status(500).send({"message": "something went wrong on the server please try after some time"})
        console.log("Error" , err)
    })
} ); 
// UPDATE
app.put("/edit/:hid", (req, res)=>{
    Hero.findByIdAndUpdate(req.params.hid,{
        title : req.body.title,
        firstname : req.body.firstname,
        lastname : req.body.lastname,
        city : req.body.city,
    })
    .then(function(dbres){
        res.status(200).send({message : "hero info was updated"})
    })
    .catch(function(err){
        console.log("Error" , err)
        res.status(500).send({"message": "hero was not updated please try after some time"})
    })
} ); 
// DELETE
app.delete("/delete/:hid", (req, res)=>{
    Hero.findByIdAndDelete({ _id: req.params.hid })
    .then(function(dbres){
        res.status(200).send({message : dbres.title+" was deleted from DB"})
    })
    .catch(function(err){
        console.log("Error" , err);
        res.status(500).send({message: "hero was not deleted, please try after some time"})
    }) 
} );  


app.listen(config.port, config.host, (err) => {
    if(err){ console.log("Error is ", err)}
    else{ console.log("server is now live on localhost:5050")}
})